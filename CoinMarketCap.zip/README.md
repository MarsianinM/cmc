# Bitcoin converter (API CoinMarketCap)
<p>
Working plugin for currency conversion, to install you need to download the plugin to the plugins folder and activate
</p>
<p>
After installation, two shortcodes will be available 
</p>

* The first will output the form for conversion ['getcoin'].  
* The second will display the last 5 conversions ['getLastConvert']